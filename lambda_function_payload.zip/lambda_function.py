from uuid import uuid4
import json
import os
import time
import boto3

def lambda_handler(event, context):
    
    current_time = int(time.time())
    unique_id = "ec2-state-change-logs-" + str(current_time) + str(uuid4())
    region = os.environ['BUCKET_REGION']
    bucket_name = os.environ['BUCKET_NAME']

    client = boto3.client('s3',region_name=region)

    json_object = event
    client.put_object(
        Body=json.dumps(json_object),
        Bucket=bucket_name,
        Key= unique_id)
    return "success"